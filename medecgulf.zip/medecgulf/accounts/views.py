from django.shortcuts import render, redirect
from accounts.forms import MerckUserCreationForm, Login
from django.contrib import auth
from django.shortcuts import render, redirect, reverse
from django.http import HttpResponse, HttpResponseRedirect, HttpResponseForbidden
from django.contrib.auth.views import LoginView

from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib import messages


def pagelogin(request):
    uservalue = ''
    passwordvalue = ''
    valuenext = request.POST.get('next')
    form = Login(request.POST or None)
    if form.is_valid():
        uservalue = form.cleaned_data.get("username")
        passwordvalue = form.cleaned_data.get("password")
        user = authenticate(username=uservalue, password=passwordvalue)
        if user is not None and valuenext == '':
            login(request, user)
            context = {'form': form, 'valuenext': valuenext}
            return render(request, 'registration/login.html', context)
        if user is not None and valuenext != '':
            login(request, user)
            context = {'form': form, 'valuenext': valuenext}
            return redirect(context)
        else:
            context = {'form': form, 'error': 'The username and password combination is incorrect'}
            return render(request, 'registration/login.html', context)
    else:
        context = {'form': form}
        return render(request, 'registration/login.html', context)

def logout(request):
    auth.logout(request)
    return HttpResponseRedirect("survey-list")


def signup(request):
    if request.method == 'POST':
        form = MerckUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = MerckUserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})
    

def password_reset_form(request):
    return render(request, 'registration/password_reset_form.html')


def password_reset_done(request):
    return render(request, 'registration/password_reset_done.html')


def password_reset_complete(request):
    return render(request, 'registration/password_reset_complete.html')


def password_reset_confirm(request):
    return render(request, 'registration/password_reset_confirm.html')

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser
from csv_export.views import CSVExportView


class CustomUserAdmin(admin.ModelAdmin):
    model = CustomUser
    list_display = ('first_name', 'last_name', 'email', 'phone_number', 'specialty', 'clinic',)
    search_fields = ('first_name', 'last_name', 'email',)
    ordering = ('email',)
    readonly_fields = ('first_name', 'last_name', 'email', 'phone_number', 'specialty', 'clinic','date_joined', 'last_login',)
    list_per_page = 25
    exclude = ['password', 'id', 'groups' ]
    actions = ('export_data_csv',)
    
    def has_add_permission(self, request, obj=None):
        return False
        
    def export_data_csv(self, request, queryset):
        view = CSVExportView(queryset=queryset, fields=['first_name','last_name','email', 'phone_number', 'specialty', 'clinic'])
        return view.get(request)

    export_data_csv.short_description = 'Export users to CSV'
    
admin.site.register(CustomUser, CustomUserAdmin)


from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
# from .models import User
from django.contrib.auth.models import User
from django import forms


class MerckUserCreationForm(UserCreationForm):
    """
    A Custom form for creating new users.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['email'].label = 'Email address'
        self.fields['first_name'].label = 'First name'
        self.fields['last_name'].label = 'Last name'
        self.fields['password1'].label = 'Password'
        self.fields['password2'].label = 'Confirm password'

        self.fields['email'].help_text = None
        self.fields['first_name'].help_text = None
        self.fields['last_name'].help_text = None
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None

    class Meta:
        model = get_user_model()
        fields = ['first_name', 'last_name', 'email', 'phone_number', 'specialty', 'clinic', ]


class Login(AuthenticationForm):
    class Meta:
        model = User
        fields = ['email']

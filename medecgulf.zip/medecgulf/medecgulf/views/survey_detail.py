import logging
from django.shortcuts import redirect, render, reverse
from django.views.generic import View
from medecgulf.decorators import survey_available
from medecgulf.forms import ResponseForm
from django.conf import settings


LOGGER = logging.getLogger(__name__)


class SurveyDetail(View):
    @survey_available
    def get(self, request, *args, **kwargs):
        survey = kwargs.get("survey")
        template_name = "survey/survey.html"
        if survey.need_logged_user and not request.user.is_authenticated:
            return redirect(f"{settings.LOGIN_URL}?next={request.path}")
        form = ResponseForm(survey=survey, user=request.user, )
        context = {
            "response_form": form,
            "survey": survey,
        }
        return render(request, template_name, context)


    @survey_available
    def post(self, request, *args, **kwargs):
        survey = kwargs.get("survey")
        if survey.need_logged_user and not request.user.is_authenticated:
            return redirect(f"{settings.LOGIN_URL}?next={request.path}")
            # return redirect('login')
        form = ResponseForm(request.POST, survey=survey, user=request.user, )
        if form.response is not None:
            LOGGER.info("Redirects to survey list after trying to edit non editable answer.")
            return redirect("survey-list")
        context = {"response_form": form, "survey": survey, }
        if form.is_valid():
            return self.treat_valid_form(form, kwargs, request, survey)
        return self.handle_invalid_form(context, form, request, survey)


    @staticmethod
    def handle_invalid_form(context, form, request, survey):
        LOGGER.info("Non valid form: <%s>", form)
        template_name = "survey/survey-list.html"
        return render(request, template_name, context)

    def treat_valid_form(self, form, kwargs, request, survey):
        session_key = "survey_{}".format(kwargs["id"])
        if session_key not in request.session:
            request.session[session_key] = {}
        for key, value in list(form.cleaned_data.items()):
            request.session[session_key][key] = value
            request.session.modified = True
        response = form.save()
        save_form = ResponseForm(request.session[session_key], survey=survey, user=response.user)
        if save_form.is_valid():
            response = save_form.save()
        else:
            LOGGER.warning("A step of the multipage form failed but should have been discovered before.")
        del request.session[session_key]
        if response is None:
            # return redirect(reverse("survey-detail"))
            return redirect(reverse("survey-list"))
        return redirect("survey-list", uuid=response.interview_uuid)

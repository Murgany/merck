from datetime import date
from django.views.generic import ListView
from medecgulf.models import Episode, Survey


# Home page views
class IndexView(ListView):
    model = Episode
    template_name = 'survey/index.html'
    context_object_name = 'episodes'
    queryset = Episode.objects.filter(make_published=True, ).order_by('-id')
    paginate_by = 1

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        surveys = Survey.objects.filter(
             publish_date__lte=date.today(), is_published=True,
        ).order_by('-id')
        context["surveys"] = surveys
        return context

from .views import IndexView, SurveyDetail, ConfirmView, SurveyCompleted
# from .views.index_view import  #table_view #, ResultView
from django.conf import settings
from django.conf.urls.static import static

try:
    from django.conf.urls import url
except ImportError:
    # Django 4.0 replaced url by something else
    # See https://stackoverflow.com/a/70319607/2519059
    from django.urls import re_path as url

urlpatterns = [
                  url(r"^$", IndexView.as_view(), name="survey-list"),
                  url(r"^(?P<id>\d+)/", SurveyDetail.as_view(), name="survey-detail"),
                  url(r"^confirm/(?P<uuid>\w+)/", ConfirmView.as_view(), name="survey-confirmation"),
                  url(r"^(?P<id>\d+)/completed/", SurveyCompleted.as_view(), name="survey-completed"),
              ] 
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


from django.contrib import admin
from .exporter.csv.survey2csv import Survey2Csv
from .actions import mark_episode_published, unpublish_episode
from .models import Answer, Question, Response, Survey, Episode, CorrectAnswer, Result
from django.utils import timezone
from django.core.paginator import Paginator

class QuestionAdmin(admin.ModelAdmin):
    list_display = ('text', 'correct_answer', 'survey')
    fields = ('text', 'correct_answer', 'survey', 'type', 'choices',)
    ordering = ('text', 'correct_answer', 'survey', 'type', 'choices',)
    exclude = ['required']
    list_per_page = 10

class QuestionInline(admin.StackedInline):
    model = Question
    exclude = ['required']
    extra = 0

class SurveyAdmin(admin.ModelAdmin):
    list_display = ("name", "publish_date", "need_logged_user")
    fields = ('name', 'description', 'need_logged_user')
    list_filter = ("name", "publish_date")
    inlines = [QuestionInline]
    readonly_fields = ('id',)
    exclude = ['required']
    list_per_page = 10
    actions = [Survey2Csv.export_as_csv]

class AnswerAdmin(admin.ModelAdmin):
    list_display = ('body', "question", )
    fields = ("question", 'body', 'response')
    # inlines = [ResponseBaseInline]
    extra = 0
    list_per_page = 10

    # removes the 'Add' button from the list display
    def has_add_permission(self, request, obj=None):
        return False

    # removes the edit feature from the form_change display. content is read only.
    def has_change_permission(self, request, obj=None):
        return False

class EpisodeAdmin(admin.ModelAdmin):
    list_display = (
        'episode_name', 'id', 'survey', 'playtime', 'episode_date', 'make_published', 'episode_publish_date',)
    fields = (
        'episode_name', 'upload_video', 'survey', 'image', 'description', 'playtime',)
    date_hierarchy = "episode_date"
    list_filter = ("episode_publish_date",)
    # change_form_template = 'admin/custom_change_form.html'
    list_per_page = 10
    actions = [mark_episode_published, unpublish_episode]

class ResultsAdmin(admin.ModelAdmin):
    search_fields = ['body', 'question__survey__name', 'question__text', 'question__correct_answer__correct_ans']
    date_hierarchy = "created"
    change_list_template = 'admin/custom_change_list.html'
    # list_per_page = 10

    def changelist_view(self, request, extra_context=None):
        response = super(ResultsAdmin, self).changelist_view(request, extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response

        from django.db.models import Count
        metrics = {
            'total': Count('id'),
            'total_answers': Count('body'),
            'total_responses': Count('response'),
        }

        response.context_data['summary'] = list(
            qs.filter(created__lte=timezone.now()).values(
                'body', 'question__correct_answer__correct_ans', 'question__survey__name',
                'question__text').annotate(**metrics).order_by('-body')
        )

        response.context_data['summary_total'] = dict(
            qs.aggregate(total=Count('response'))
        )

        return response

    # removes the 'Add' button from the list display
    def has_add_permission(self, request, obj=None):
        return False

    # removes the edit feature from the form_change display. content is read only.
    def has_change_permission(self, request, obj=None):
        return False

admin.site.register(Question, QuestionAdmin)
admin.site.register(Answer, AnswerAdmin)
# admin.site.register(Response, ResponseAdmin)
admin.site.register(Survey, SurveyAdmin)
admin.site.register(Episode, EpisodeAdmin)
admin.site.register(CorrectAnswer)
admin.site.register(Result, ResultsAdmin)

admin.site.site_title = "MedecGulf admin site"

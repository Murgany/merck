from django.utils.translation import gettext_lazy as _
from django.utils.translation import ngettext
from django.utils.timezone import now
import datetime

def mark_episode_published(modeladmin, request, queryset):
    """
    Mark the given episode as published
    """
    count = queryset.update(make_published=True)

    publication_date = queryset.update(episode_publish_date=datetime.datetime.now())

    message = ngettext(
        "%(count)d episode was successfully marked as published.",
        "%(count)d episodes were successfully marked as published",
        count,
    ) % {"count": count, 'publication_date': publication_date}
    modeladmin.message_user(request, message)

mark_episode_published.short_description = _("Mark selected Episodes as published")


def unpublish_episode(modeladmin, request, queryset):
    """
    Mark the given episode as NOT published
    """
    count = queryset.update(make_published=False)

    message = ngettext(
        "%(count)d episode was successfully unpublished.",
        "%(count)d episodes were successfully unpublished",
        count,
    ) % {"count": count}
    modeladmin.message_user(request, message)

unpublish_episode.short_description = _("Mark selected Episodes as NOT published")
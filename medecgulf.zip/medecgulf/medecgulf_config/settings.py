
import os
from django.conf import settings
import dotenv
from pathlib import Path
from dotenv import load_dotenv
import dj_database_url

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
DEBUG = False
SECRET_KEY = str(os.getenv('SECRET_KEY'))
# DEBUG = os.environ.get('DJANGO_DEBUG', '') != 'False'

SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_BROWSER_XSS_FILTER = True

ALLOWED_HOSTS = ['medecgulf.com', 'www.medecgulf.com', 'theexpertologists.com', 'theexpertologists.com']

CORS_ORIGIN_WHITELIST = ('medecgulf.com', 'www.medecgulf.com')
CORS_ALLOWED_ORIGINS = ['medecgulf.com', 'www.medecgulf.com']
ACCESS_CONTROL_ALLOW_ORIGIN = ['medecgulf.com', 'www.medecgulf.com']
CSRF_TRUSTED_ORIGINS  = ['medecgulf.com', 'www.medecgulf.com']

# Application definition
INSTALLED_APPS = [
    'jazzmin',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    'medecgulf.apps.MedecgulfConfig',
    'accounts.apps.AccountsConfig',
    'crispy_forms',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]


AUTH_USER_MODEL = 'accounts.CustomUser'
DURATIONFIELD_ALLOW_MONTHS = True
ROOT_URLCONF = 'medecgulf_config.urls'

ROOT = os.path.dirname(os.path.abspath(__file__))
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR,'templates')], 
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'medecgulf_config.wsgi.application'

# Database
# https://docs.djangoproject.com/en/3.2/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'medecgulf_db',
        'USER': 'medecgulf_db_admin',
        'PASSWORD': '66wnwpAUDwNjegf',
        'HOST': '72.167.64.243',
    }
}

# db_from_env = dj_database_url.config(conn_max_age=500)
# DATABASES['default'].update(db_from_env)

# dotenv_file = os.path.join(BASE_DIR, '.env')
# if os.path.isfile(dotenv_file):
#     dotenv.load_dotenv(dotenv_file)

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.db.DatabaseCache',
                    # 'django.core.cache.backends.memcached.PyMemcacheCache',
        'LOCATION': 'merck_cache_table' #'72.167.64.243',
    }
}

# Password validation
# https://docs.djangoproject.com/en/3.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/3.2/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/3.2/howto/static-files/

STATIC_URL = '/static/'
STATIC_ROOT = '/home/nezqv2mzcgqi/public_html/medecgulf.com/static'
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]
MEDIA_URL = '/media/'
MEDIA_ROOT = '/home/nezqv2mzcgqi/public_html/medecgulf.com/media'

CRISPY_TEMPLATE_PACK = 'bootstrap4'

LOGIN_REDIRECT_URL = "/"
LOGOUT_REDIRECT_URL = "/"

CSV_DIRECTORY = os.path.join(ROOT, "csv")
TEX_DIRECTORY = os.path.join(ROOT, "tex")
EXCEL_COMPATIBLE_CSV = True

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

DEFAULT_SURVEY_PUBLISHING_DURATION = 60
CHOICES_SEPARATOR = ","
USER_DID_NOT_ANSWER = "Left blank"
X_FRAME_OPTIONS = 'SAMEORIGIN'
TEX_CONFIGURATION_FILE = os.path.join(ROOT, "doc", "example_conf.yaml")


JAZZMIN_SETTINGS = {
    "site_title": "MedecGulf Admin",
    # "site_header": "Merck",
    "site_brand": "MedecGulf",
    "site_logo": "/media/images/m-logo.svg",
    "login_logo": "/media/images/page_logo.svg",
    "login_logo_dark": "/media/images/page_logo.svg",

    # CSS classes that are applied to the logo above
    "site_logo_classes": "",

    # Relative path to a favicon for your site, will default to site_logo if absent (ideally 32x32 px)
    # "site_icon": None,

    # Welcome text on the admin login screen
    "welcome_sign": "Welcome to Medecgulf",

    # Copyright on the admin footer
    "copyright": "Medecgulf",

    # The model admin to search from the search bar, search bar omitted if excluded
    "search_model": "medecgulf.Episode",

    # Field name on user model that contains avatar ImageField/URLField/Charfield or a callable that receives the user
    "user_avatar": None,

    ############
    # Top Menu #
    ############

    # Links to put along the top menu
    "topmenu_links": [
        {"name": "Go to site", "url": "https://www.medecgulf.com", "new_window": True},
    ],

    #############
    # User Menu #
    #############

    # Additional links to include in the user menu on the top right ("app" url type is not allowed)
    "usermenu_links": [
        # {"name": "Results", "url": "http://127.0.0.1:8000/results", "new_window": True},
        # {"model": "merck.Episode"}
    ],

    #############
    # Side Menu #
    #############

    # Whether to display the side menu
    "show_sidebar": True,

    # Whether to aut expand the menu
    "navigation_expanded": True,

    # Hide these apps when generating side menu e.g (auth)
    "hide_apps": ["auth"],

    # Hide these models when generating side menu (e.g auth.user)
    "hide_models": ["medecgulf.CorrectAnswer"],

    # List of apps (and/or models) to base side menu ordering off of (does not need to contain all apps/models)
    "order_with_respect_to": ["medecgulf", "accounts", "medecgulf.Episode", "medecgulf.Survey", "medecgulf.Question", "medecgulf.Answer", "medecgulf.Result"],

    # Custom icons for side menu apps/models.
    "icons": {
        "auth": "fas fa-users-cog",
        "auth.user": "fas fa-user",
        "auth.Group": "fas fa-users",
    },

    # Related Modal #
    # Use modals instead of popups
    "related_modal_active": False,

    #############
    # UI Tweaks #
    #############
    # Relative paths to custom CSS/JS scripts (must be present in static files)
    "custom_css": None,
    "custom_js": None,
    # Whether to show the UI customizer on the sidebar
    "show_ui_builder": False,

    ###############
    # Change view #
    ###############
    # Render out the change view as a single form, or in tabs, current options are
    # - single
    # - horizontal_tabs (default)
    # - vertical_tabs
    # - collapsible
    # - carousel
    "changeform_format": "single",
    # override change forms on a per modeladmin basis
    "changeform_format_overrides": {"medecgulf.Survey": "collapsible"},
    # Add a language dropdown into the admin
    # "language_chooser": True,
}

JAZZMIN_UI_TWEAKS = {
     "navbar_small_text": True,
    "footer_small_text": False,
    "body_small_text": False,
    "brand_small_text": False,
    "brand_colour": "navbar-lightblue",
    "accent": "accent-primary",
    "navbar": "navbar-white navbar-light",
    "no_navbar_border": False,
    "navbar_fixed": False,
    "layout_boxed": False,
    "footer_fixed": False,
    "sidebar_fixed": False,
    "sidebar": "sidebar-dark-info",
    # "sidebar": "sidebar-light-primary",
    "sidebar_nav_small_text": False,
    "sidebar_disable_expand": False,
    "sidebar_nav_child_indent": False,
    "sidebar_nav_compact_style": False,
    "sidebar_nav_legacy_style": False,
    "sidebar_nav_flat_style": False,
    "theme": "pulse",
    "dark_mode_theme": None,
    "button_classes": {
        "primary": "btn-primary",
        "secondary": "btn-outline-secondary",
        "info": "btn-outline-info",
        "warning": "btn-outline-warning",
        "danger": "btn-danger",
        "success": "btn-outline-success"
    }
}

